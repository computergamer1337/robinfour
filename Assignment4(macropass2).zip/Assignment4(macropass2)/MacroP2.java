import java.io.*;
import java.util.*;

class MNTEntry {

	public String name;
	public int pp, kp, mdtp, kpdtp;
	
	public MNTEntry(String name, int pp, int kp, int mdtp, int kpdtp) {
		this.name = name;
		this.pp = pp;
		this.kp = kp;
		this.mdtp = mdtp;
		this.kpdtp = kpdtp;
	}

}

public class MacroP2 {

	public static void main(String[] args) throws IOException {
		BufferedReader input = new BufferedReader(new FileReader("IC_output.txt"));
		BufferedReader mdtfile = new BufferedReader(new FileReader("MDT.txt"));
		BufferedReader mntfile = new BufferedReader(new FileReader("MNT.txt"));
		BufferedReader kpdtfile = new BufferedReader(new FileReader("KPDT.txt"));
		
		BufferedWriter output = new BufferedWriter(new FileWriter("output.txt"));
		
		HashMap<String, MNTEntry> mnt = new HashMap<>();
		ArrayList<String> mdt = new ArrayList<>();
		ArrayList<String> kpdt = new ArrayList<>();
		
		String line;
		
		while ((line = mdtfile.readLine()) != null) {
			mdt.add(line);
		}
		mdtfile.close();
		
		while ((line = kpdtfile.readLine()) != null) {
			kpdt.add(line);
		}
		kpdtfile.close();
		
		while ((line = mntfile.readLine()) != null) {
			String[] parts = line.split("\\s+");
			mnt.put(parts[0], new MNTEntry(parts[0], Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3]), Integer.parseInt(parts[4])));
		}
		mntfile.close();
		
		while ((line = input.readLine()) != null) {
			String[] parts = line.split("\\s+");
			
			// Macro call
			if (mnt.containsKey(parts[0])) {
				HashMap<Integer, String> aptab = new HashMap<>();		// Actual Parameter Table
				HashMap<String, Integer> aptabInv = new HashMap<>();
				
				MNTEntry entry = mnt.get(parts[0]);
				int pp = entry.pp;
				int kp = entry.kp;
				int mdtp = entry.mdtp;
				int kpdtp = entry.kpdtp;
				int paramNo = 1;
				
				// Read and store positional parameters
				for (paramNo = 1; paramNo <= pp; paramNo++) {
					parts[paramNo] = parts[paramNo].replace(",", "");
					aptab.put(paramNo, parts[paramNo]);
					aptabInv.put(parts[paramNo], paramNo);
				}
				
				// Store keyword parameters default values
				for (int i = kpdtp-1; i < kpdtp+kp-1; i++, paramNo++) {
					String[] temp = kpdt.get(i).split("\t");
					aptab.put(paramNo, temp[1]);
					aptabInv.put(temp[0], paramNo);
				}
				
				// Read and store keyword parameters
				for (int i = pp+1; i < parts.length; i++) {
					parts[i] = parts[i].replace(",", "");
					String[] split = parts[i].split("=");
					String name = split[0].replace("&", "");
					aptab.put(aptabInv.get(name), split[1]);
				}
				
				int i = mdtp-1;
				while (!mdt.get(i).equalsIgnoreCase("MEND")) {
					String[] split = mdt.get(i).split("\\s+");
					output.write("+");
					for (int k = 0; k < split.length; k++) {
						if (split[k].contains("#")) {
							String value = aptab.get(Integer.parseInt(split[k].replace("#", "")));
							output.write(value + "\t");
						} else {
							output.write(split[k] + "\t");
						}
					}
					output.write("\n");
					i++;
				}
			}
			
			// Normal statement
			else {
				output.write(line + "\n");
			}
		}
		
		input.close();
		output.close();
	}

}
